#!/bin/bash

# Function to reverse a number
reverse_number() {
    local num="$1"
    local reversed=""
    while [ "$num" -gt 0 ]; do
        digit=$(( num % 10 ))
        reversed="${reversed}${digit}"
        num=$(( num / 10 ))
    done
    echo "$reversed"
}

# Main script
echo "Enter a four-digit number:"
read number

# Check if the entered number is exactly four digits
if [[ $number =~ ^[0-9]{4}$ ]]; then
    reversed=$(reverse_number "$number")
    echo "Reversed number: $reversed"
else
    echo "Error: Please enter a valid four-digit number."
fi
