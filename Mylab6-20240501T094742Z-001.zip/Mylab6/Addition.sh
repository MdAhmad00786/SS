#!/bin/bash

echo "Welcome to the addition program!"
read -p "Enter the number of values you want to add: " n

total=0
for ((i=1; i<=$n; i++))
do
    read -p "Enter number $i: " num
    total=$(awk "BEGIN {print $total + $num}")
done

echo "The sum of the numbers is: $total"

