#!/bin/bash

# Function to convert a number less than 100 into words
convert_less_than_100() {
    local num="$1"
    local ones=("zero" "one" "two" "three" "four" "five" "six" "seven" "eight" "nine")
    local teens=("ten" "eleven" "twelve" "thirteen" "fourteen" "fifteen" "sixteen" "seventeen" "eighteen" "nineteen")
    local tens=("twenty" "thirty" "forty" "fifty" "sixty" "seventy" "eighty" "ninety")
    
    local result=""
    if [ "$num" -lt 10 ]; then
        result="${ones[$num]}"
    elif [ "$num" -lt 20 ]; then
        result="${teens[$((num - 10))]}"
    else
        local ten=$((num / 10))
        local one=$((num % 10))
        if [ "$one" -eq 0 ]; then
            result="${tens[$((ten - 2))]}"
        else
            result="${tens[$((ten - 2))]}-${ones[$one]}"
        fi
    fi
    echo "$result"
}

# Function to convert a three-digit number into words
convert_less_than_1000() {
    local num="$1"
    local hundreds=$((num / 100))
    local tens_and_ones=$((num % 100))
    
    local result=""
    if [ "$hundreds" -gt 0 ]; then
        result+="$(convert_less_than_100 "$hundreds") hundred"
        if [ "$tens_and_ones" -gt 0 ]; then
            result+=" and "
        fi
    fi
    if [ "$tens_and_ones" -gt 0 ]; then
        result+="$(convert_less_than_100 "$tens_and_ones")"
    fi
    echo "$result"
}

# Main script
echo "Enter a four-digit number:"
read number

# Check if the entered number is exactly four digits
if [[ $number =~ ^[0-9]{4}$ ]]; then
    thousand=$((number / 1000))
    remaining=$((number % 1000))
    if [ "$thousand" -gt 0 ]; then
        echo "$(convert_less_than_100 "$thousand") thousand"
    fi
    if [ "$remaining" -gt 0 ]; then
        echo "$(convert_less_than_1000 "$remaining")"
    fi
else
    echo "Error: Please enter a valid four-digit number."
fi
