#!/bin/bash

# Function to check if a number is even
is_even() {
    local num="$1"
    if [ $((num % 2)) -eq 0 ]; then
        echo "even"
    else
        echo "odd"
    fi
}

# Main script
echo "Enter a four-digit number:"
read number

# Check if the entered number is exactly four digits
if [[ $number =~ ^[0-9]{4}$ ]]; then
    digit1=$((number / 1000))
    digit2=$((number / 100 % 10))
    digit3=$((number / 10 % 10))
    digit4=$((number % 10))

    echo "Digits:"
    echo "1st digit: $digit1 ($(is_even $digit1))"
    echo "2nd digit: $digit2 ($(is_even $digit2))"
    echo "3rd digit: $digit3 ($(is_even $digit3))"
    echo "4th digit: $digit4 ($(is_even $digit4))"
else
    echo "Error: Please enter a valid four-digit number."
fi

