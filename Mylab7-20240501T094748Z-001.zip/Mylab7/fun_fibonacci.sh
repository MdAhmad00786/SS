#!/bin/bash

# Function to calculate the Fibonacci series
fibonacci() {
    n=$1
    a=0
    b=1

    echo -n "Fibonacci Series up to $n terms: "

    # Loop to calculate Fibonacci series up to n terms
    for (( i=0; i<n; i++ ))
    do
        echo -n "$a "
        fn=$((a + b))
        a=$b
        b=$fn
    done
    echo
}

# Take user input for the number of terms
read -p "Enter the number of terms for Fibonacci series: " num_terms

# Call the fibonacci function with user input
fibonacci $num_terms
