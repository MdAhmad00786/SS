#!/bin/bash


echo "Enter your email address:"
read email

email=$(echo "$email" | tr '[:upper:]' '[:lower:]')

email_regex="^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"

if [[ $email =~ $email_regex ]]; then
    echo $email
    echo "Valid email address."
else
    echo "Invalid email address."
fi

