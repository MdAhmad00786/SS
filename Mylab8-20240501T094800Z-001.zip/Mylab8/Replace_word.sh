#!/bin/bash

replace_word() {
    local sentence="$1"
    local old_word="$2"
    local new_word="$3"

    # Use sed to replace the word
    new_sentence=$(echo "$sentence" | sed "s/\b$old_word\b/$new_word/g")

    echo "Original sentence: $sentence"
    echo "Modified sentence: $new_sentence"
}

read -p "Enter a sentence: " input_sentence

read -p "Enter the word to be replaced: " old_word

read -p "Enter the replacement word: " new_word

replace_word "$input_sentence" "$old_word" "$new_word"
