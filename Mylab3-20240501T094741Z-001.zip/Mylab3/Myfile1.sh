#! /bin/bash/

greeting="Hello"
name="Md Ahmad"
echo $greeting $name

a=15
b=25

Addition=$((a+b))
echo "Your Answer is : $Addition"

Subtraction=$((a-b))
echo "Your Answer is : $Subtraction"

Multiplication=$((a*b))
echo "Your Answer is :$Multiplication"

Divide=$((a/b))
echo "Your Answer is : $Divide"

persentage=$((a%b))
echo "Your Answer is : $persentage"

exponent=$((a**b))
echo "Your Answer is : $exponent"

