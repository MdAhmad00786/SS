#!/bin/sh

echo "Enter Num1 : "
read num1
echo "Enter Num2 : "
read num2

if [ $num1 -gt $num2 ]
then
    echo "Your Answer is :  $num1"
elif [ $num2 -gt $num1 ]
then
    echo "Your Answer is :  $num2"
elif [$num1 -eq $num2]
then
    echo "Your Both  Answers are equal :  $num3"
fi
